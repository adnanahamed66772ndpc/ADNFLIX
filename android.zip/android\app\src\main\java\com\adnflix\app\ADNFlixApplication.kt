package com.adnflix.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ADNFlixApplication : Application()
